-- Student Registration System database schema
-- Run this script in SQL Server Management Studio against your Osrs database.

IF OBJECT_ID('dbo.student', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.student
    (
        id INT IDENTITY(1,1) PRIMARY KEY,
        stname NVARCHAR(100) NOT NULL,
        course NVARCHAR(100) NOT NULL,
        fee DECIMAL(18,2) NOT NULL CHECK (fee >= 0)
    );
END;
